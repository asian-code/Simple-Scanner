
#!/usr/bin/python

# I removed the explanation cause im a dummy - asian-code