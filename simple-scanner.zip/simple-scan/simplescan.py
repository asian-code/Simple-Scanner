#!/usr/bin/python

import core

core.clear()
core.logo()
core.options()
